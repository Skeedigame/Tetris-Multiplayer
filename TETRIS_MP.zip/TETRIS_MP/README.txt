<p align="center">
<img src="https://i.imgur.com/35IA11d.png" </a>
## ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎                          Tetris Multiplayer

---
Tetris Multiplayer is a fork of an old version of tetris I found online. Play Tetris alongside your friends in a intense 1v1!


---


##Installation:
1. Extract the zip and open 'Tetris.exe'
2. If you get a warning from windows, press on the underlined text that says 'More Info' then 'Run Anyway'. It's not dangerous, Windows just can't verify the program because it's not been signed by a corporation.

---

After you run the exe it may appear as nothing has happened. Just wait patiently as the game is creating the
neccessary directories to run. If a extended amount of time has passed and the game still hasn't opened, run
the file again.